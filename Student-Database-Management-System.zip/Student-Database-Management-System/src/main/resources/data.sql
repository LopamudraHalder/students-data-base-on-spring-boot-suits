insert into student(id, name) values(10, 'Adi');
insert into student(id, name) values(20, 'Ksh');

insert into course(id, name) values(10, 'Java');
insert into course(id, name) values(20, 'Python');

insert into passport(id, number) values(10, '1234');
insert into passport(id, number) values(20, '5678');

insert into review(id, rating, description) values(10, '5', 'Best');
insert into review(id, rating, description) values(20, '4', 'Good');